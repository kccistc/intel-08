/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>

#include "ssd1306.h"      // <-- OLED 라이브러리 헤더 추가
#include "ssd1306_fonts.h"// <-- OLED 폰트 헤더 추가
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* With GCC, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
#define ARR_CNT 5
#define CMD_SIZE 50
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */


/* 후륜 모터 제어 핀 매핑 */
//오른쪽바퀴
#define Moter2_In1_Pin GPIO_PIN_4
#define Moter2_In1_GPIO_Port GPIOB
#define Moter1_In2_Pin GPIO_PIN_5
#define Moter1_In2_GPIO_Port GPIOB


//왼쪽바퀴
#define Moter3_In3_Pin GPIO_PIN_6
#define Moter3_In3_GPIO_Port GPIOA
#define Moter4_In4_Pin GPIO_PIN_7
#define Moter4_In4_GPIO_Port GPIOA





/* 전륜 모터 제어 핀 매핑 */



//왼쪽바퀴 서보모터
//오른쪽바퀴 서보모터



/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

// CAN 통신에 필요한 변수들
CAN_TxHeaderTypeDef   TxHeader;
CAN_RxHeaderTypeDef   RxHeader;
uint8_t               TxData[8];
uint8_t               RxData[8];
uint32_t              TxMailbox;



uint8_t rx2char;
volatile unsigned char rx2Flag = 0;
volatile char rx2Data[50];
volatile unsigned char btFlag = 0;
uint8_t btchar;
char btData[50];

// ▼▼▼▼▼ 현재 모터 속도를 저장할 전역 변수 추가 ▼▼▼▼▼
volatile uint16_t right_motor_pwm = 0;
volatile uint16_t left_motor_pwm = 0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_SPI2_Init(void);
static void MX_CAN_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
void bluetooth_Event();
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int _write(int file, char *ptr, int len) {
    HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}


//오른쪽바퀴 전진 함수
void Motor_Forward(uint16_t speed) {
    // #define으로 정의된 이름을 사용하도록 수정
	right_motor_pwm = speed; // <-- 현재 PWM 값 저장
    HAL_GPIO_WritePin(Moter2_In1_GPIO_Port, Moter2_In1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Moter1_In2_GPIO_Port, Moter1_In2_Pin, GPIO_PIN_RESET);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, speed); // ENA 바퀴속도 설정
}

void Motor_Stop(void) {
	right_motor_pwm = 0;
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);
}


void Delay_us(uint16_t us) {
    __HAL_TIM_SET_COUNTER(&htim4, 0);  // TIM5는 1MHz로 설정됨 (1us 단위)
    while (__HAL_TIM_GET_COUNTER(&htim4) < us);
}



//왼쪽 바퀴 전진 함수
void Motor_Left_Forward(uint16_t speed) {
    // 왼쪽 바퀴를 앞으로 회전하도록 방향 설정
	left_motor_pwm = speed; // <-- 현재 PWM 값 저장
    HAL_GPIO_WritePin(Moter3_In3_GPIO_Port, Moter3_In3_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Moter4_In4_GPIO_Port, Moter4_In4_Pin, GPIO_PIN_RESET);
    // 왼쪽 바퀴 속도 설정 (ENB)
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, speed);
}


void Motor_Left_Stop(void) {
    // 왼쪽 바퀴 속도를 0으로 만들어 정지
	left_motor_pwm = 0;
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 0);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_SPI2_Init();
  MX_CAN_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */


  printf("------- STM32 CAN Sender/Receiver -------\r\n");

  if (HAL_CAN_Start(&hcan) != HAL_OK) {
      printf("Error: CAN Start failed.\r\n");
      Error_Handler();
    }

    // 수신 FIFO에 메시지가 있을 때를 감지하도록 활성화
    HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);

    // 2. 전송할 메시지 헤더 설정
    TxHeader.StdId = 0x103;      // STM32의 고유 CAN ID
    TxHeader.RTR = CAN_RTR_DATA; // 데이터 프레임
    TxHeader.IDE = CAN_ID_STD;   // 표준 ID
    TxHeader.DLC = 8;            // 데이터 길이 8바이트
    TxHeader.TransmitGlobalTime = DISABLE;




  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1); //오른쪽바퀴
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2); //왼쪽바퀴


  HAL_UART_Receive_IT(&huart2, &rx2char,1);
  HAL_UART_Receive_IT(&huart1, &btchar,1);
  printf("start main2()\r\n");


  HAL_TIM_Base_Start(&htim4); //딜레이 전용 타이머

  ssd1306_Init(); // OLED 초기화
  ssd1306_Fill(Black); // 화면 전체를 검은색으로 지웁니다.
  ssd1306_SetCursor(5, 5); // 글씨를 쓸 시작 위치(x, y)를 정합니다.
  ssd1306_WriteString("AI CAR Project", Font_7x10, White); // "AI CAR Project" 문구 표시
  ssd1306_SetCursor(25, 20);
  ssd1306_WriteString("System Ready!", Font_7x10, White);

  ssd1306_UpdateScreen(); // 화면에 실제로 내용을 업데이트합니다. (필수)
  HAL_Delay(2000); // 2초간 시작 메시지를 보여줍니다.

  uint32_t oled_update_tick = 0;
  uint32_t motor_update_tick = 0;
  uint16_t current_speed = 4000;
  uint8_t is_accelerating = 1; // 1: 가속 중, 0: 감속 중


  uint16_t speed = 4000; // 현재 속도를 저장할 변수
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {






	  // --- 1초마다 메시지 전송 ---
	      TxData[0]++; // 매번 다른 값을 보내기 위해 1씩 증가
	      TxData[1] = 0xDE;
	      TxData[2] = 0xAD;
	      TxData[3] = 0xBE;
	      TxData[4] = 0xEF;

	      if (HAL_CAN_AddTxMessage(&hcan, &TxHeader, TxData, &TxMailbox) == HAL_OK) {
	        printf("STM32 Sent -> ID: 0x%lX, Data[0]: 0x%X\r\n", TxHeader.StdId, TxData[0]);
	      } else {
	        printf("STM32 Sent -> FAILED\r\n");
	      }

	      // --- 메시지 수신 확인 (폴링) ---
	      // 수신 버퍼(FIFO0)에 메시지가 있는지 확인
	      if (HAL_CAN_GetRxFifoFillLevel(&hcan, CAN_RX_FIFO0) > 0)
	      {
	        // 메시지가 있다면 읽어오기
	        if (HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &RxHeader, RxData) == HAL_OK)
	        {
	          printf("STM32 Received <- ID: 0x%lX, Data: ", RxHeader.StdId);
	          for (int i = 0; i < RxHeader.DLC; i++) {
	            printf("0x%X ", RxData[i]);
	          }
	          printf("\r\n\n");
	        }
	      }

	      HAL_Delay(1000); // 1초 대기

//	   // ==========================================================
//	        // ▼▼ 10ms 마다 모터 속도 점진적 변경 (가속/감속) ▼▼
//	        if (HAL_GetTick() - motor_update_tick > 10)
//	        {
//	            motor_update_tick = HAL_GetTick(); // 현재 시간 기록
//
//	            if (is_accelerating) // 가속 모드일 때
//	            {
//	                current_speed += 10;
//	                if (current_speed >= 6000)
//	                {
//	                    current_speed = 6000;
//	                    is_accelerating = 0; // 감속 모드로 전환
//	                }
//	            }
//	            else // 감속 모드일 때
//	            {
//	                current_speed -= 10;
//	                if (current_speed <= 4000)
//	                {
//	                    current_speed = 4000;
//	                    is_accelerating = 1; // 가속 모드로 전환
//	                }
//	            }
//	            // 계산된 속도로 모터 제어
//	            Motor_Forward(current_speed);
//	            Motor_Left_Forward(current_speed);
//	        }
//
//	        // ==========================================================
//	        // ▼▼ 100ms 마다 OLED 화면 업데이트 ▼▼
//	        if (HAL_GetTick() - oled_update_tick > 100)
//	        {
//	            oled_update_tick = HAL_GetTick(); // 현재 시간 기록
//
//	            char left_speed_str[20];
//	            char right_speed_str[20];
//
//	            int left_kmh = left_motor_pwm / 100;
//	            int right_kmh = right_motor_pwm / 100;
//
//	            sprintf(left_speed_str, "L: %d km/h", left_kmh);
//	            sprintf(right_speed_str, "R: %d km/h", right_kmh);
//
//	            ssd1306_Fill(Black);
//	            ssd1306_SetCursor(0, 5);
//	            ssd1306_WriteString(left_speed_str, Font_11x18, White);
//	            ssd1306_SetCursor(0, 25);
//	            ssd1306_WriteString(right_speed_str, Font_11x18, White);
//	            ssd1306_UpdateScreen();
//	        }
//
//
//
//
//	  if(rx2Flag)
//	  {
//			printf("recv2 : %s\r\n",rx2Data);
//			rx2Flag =0;
//	//	    HAL_UART_Transmit(&huart6, (uint8_t *)buf, strlen(buf), 0xFFFF);
//	  }
//	  if(btFlag)
//	  {
////		printf("bt : %s\r\n",btData);
//			btFlag =0;
//			bluetooth_Event();
//	  }
//
//    /* USER CODE END WHILE */
//
//    /* USER CODE BEGIN 3 */
//
//

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN1;
  hcan.Init.Prescaler = 6;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_9TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */
  CAN_FilterTypeDef sFilterConfig;

    sFilterConfig.FilterBank = 0; // 필터 뱅크 0번 사용
    sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK; // 마스크 모드
    sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT; // 32비트 스케일
    sFilterConfig.FilterIdHigh = 0x0000;
    sFilterConfig.FilterIdLow = 0x0000;
    sFilterConfig.FilterMaskIdHigh = 0x0000;
    sFilterConfig.FilterMaskIdLow = 0x0000; // ID와 MASK를 모두 0으로 하여 모든 메시지를 통과시킴
    sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0; // 수신된 메시지를 FIFO 0에 저장
    sFilterConfig.FilterActivation = ENABLE; // 필터 활성화
    sFilterConfig.SlaveStartFilterBank = 14;

    if (HAL_CAN_ConfigFilter(&hcan, &sFilterConfig) != HAL_OK)
    {
      /* Filter configuration Error */
      Error_Handler();
    }
  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 83;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 71;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|GPIO_PIN_6|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, UltrasonicSensor_Trig_Pin|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pins : B1_Pin UltrasonicSensor_Echo_Pin */
  GPIO_InitStruct.Pin = B1_Pin|UltrasonicSensor_Echo_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin PA6 PA7 */
  GPIO_InitStruct.Pin = LD2_Pin|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : UltrasonicSensor_Trig_Pin PB4 PB5 */
  GPIO_InitStruct.Pin = UltrasonicSensor_Trig_Pin|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void MX_GPIO_LED_ON(int pin)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, pin, GPIO_PIN_SET);
}
void MX_GPIO_LED_OFF(int pin)
{
	HAL_GPIO_WritePin(LD2_GPIO_Port, pin, GPIO_PIN_RESET);
}
void bluetooth_Event()
{

  int i=0;
  char * pToken;
  char * pArray[ARR_CNT]={0};
  char recvBuf[CMD_SIZE]={0};
  char sendBuf[CMD_SIZE]={0};
  strcpy(recvBuf,btData);

  printf("btData : %s\r\n",btData);

  pToken = strtok(recvBuf,"[@]");
  while(pToken != NULL)
  {
    pArray[i] =  pToken;
    if(++i >= ARR_CNT)
      break;
    pToken = strtok(NULL,"[@]");
  }
//  printf("pArray[0] : %s\r\n",pArray[0]);
//  printf("pArray[1] : %s\r\n",pArray[1]);
//  printf("pArray[2] : %s\r\n",pArray[2]);

  if(!strcmp(pArray[1],"LED"))
  {
		if(!strcmp(pArray[2],"ON"))
		{
			MX_GPIO_LED_ON(LD2_Pin);
		}
		else if(!strcmp(pArray[2],"OFF"))
		{
			MX_GPIO_LED_OFF(LD2_Pin);
		}
  }
  else if(!strncmp(pArray[1]," New conn",sizeof(" New conn")))
  {
      return;
  }
  else if(!strncmp(pArray[1]," Already log",sizeof(" Already log")))
  {
      return;
  }
  else
      return;

  sprintf(sendBuf,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
  HAL_UART_Transmit(&huart1, (uint8_t *)sendBuf, strlen(sendBuf), 0xFFFF);

}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // --- USART2 (PC 통신) 처리 ---
    if(huart->Instance == USART2)
    {
        static int i_pc = 0; // PC용 인덱스 변수

        rx2Data[i_pc] = rx2char;

        // 버그 수정: btData가 아닌 rx2Data로 확인해야 합니다.
        if((rx2Data[i_pc] == '\r') || (rx2Data[i_pc] == '\n'))
        {
            rx2Data[i_pc] = '\0';
            rx2Flag = 1;
            i_pc = 0;
        }
        else
        {
            // 버퍼 오버플로우 방지
            if(i_pc < sizeof(rx2Data) - 1)
            {
                i_pc++;
            }
        }
        HAL_UART_Receive_IT(&huart2, &rx2char, 1);
    }

    // --- USART1 (블루투스 통신) 처리 ---
    // 버그 수정: 코드 상단에 huart3가 아닌 huart1로 선언되어 있으므로 USART1로 변경해야 합니다.
    if(huart->Instance == USART1)
    {
        static int i_bt = 0; // 블루투스용 인덱스 변수

        btData[i_bt] = btchar;

        if((btData[i_bt] == '\n') || (btData[i_bt] == '\r'))
        {
            btData[i_bt] = '\0';
            btFlag = 1;
            i_bt = 0;
        }
        else
        {
            // 버퍼 오버플로우 방지
            if(i_bt < sizeof(btData) - 1)
            {
                i_bt++;
            }
        }
        HAL_UART_Receive_IT(&huart1, &btchar, 1);
    }
}





/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
